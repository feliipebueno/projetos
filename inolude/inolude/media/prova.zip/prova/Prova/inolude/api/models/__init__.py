from .forma_model import *
from .materia_model import *
from .processo_model import *
from .tipoprocesso_model import *