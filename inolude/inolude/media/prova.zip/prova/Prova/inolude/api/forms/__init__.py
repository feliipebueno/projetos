from .forma_form import *
from .materia_form import *
from .processo_form import *
from .tipoprocesso_form import *