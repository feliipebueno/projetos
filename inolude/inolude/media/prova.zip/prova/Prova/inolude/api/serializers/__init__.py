from .forma_serializer import *
from .materia_serializer import *
from .processo_serializer import *
from .tipoprocesso_serializer import *