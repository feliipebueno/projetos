-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: dbinolude
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbforma`
--

DROP TABLE IF EXISTS `tbforma`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbforma` (
  `cod_Forma` int(11) NOT NULL AUTO_INCREMENT,
  `de_Forma` varchar(45) NOT NULL,
  `sg_Forma` varchar(45) NOT NULL,
  PRIMARY KEY (`cod_Forma`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbforma`
--

LOCK TABLES `tbforma` WRITE;
/*!40000 ALTER TABLE `tbforma` DISABLE KEYS */;
INSERT INTO `tbforma` VALUES (1,'Eletronico','E'),(2,'Fisico','F');
/*!40000 ALTER TABLE `tbforma` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbmateria`
--

DROP TABLE IF EXISTS `tbmateria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbmateria` (
  `cod_TipoMateria` int(11) NOT NULL AUTO_INCREMENT,
  `de_TipoMateria` varchar(45) NOT NULL,
  `sg_TipoMateria` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cod_TipoMateria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbmateria`
--

LOCK TABLES `tbmateria` WRITE;
/*!40000 ALTER TABLE `tbmateria` DISABLE KEYS */;
INSERT INTO `tbmateria` VALUES (1,'Trabalhista','T'),(2,'Civel','C'),(3,'Criminal','R');
/*!40000 ALTER TABLE `tbmateria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbprocesso`
--

DROP TABLE IF EXISTS `tbprocesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbprocesso` (
  `cod_Processo` int(11) NOT NULL AUTO_INCREMENT,
  `nu_Processo` bigint(10) unsigned NOT NULL,
  `dt_Processo` date NOT NULL,
  `ar_Processo` varchar(45) NOT NULL,
  `vl_Processo` double DEFAULT NULL,
  `cod_TipoProcesso` int(11) NOT NULL,
  `cod_Materia` int(11) NOT NULL,
  `cod_Forma` int(11) NOT NULL,
  PRIMARY KEY (`cod_Processo`),
  KEY `fk_tbprocesso_1_idx` (`cod_Forma`),
  KEY `fk_tbprocesso_2_idx` (`cod_Materia`),
  KEY `fk_tbprocesso_3_idx` (`cod_TipoProcesso`),
  CONSTRAINT `fk_tbprocesso_1` FOREIGN KEY (`cod_Forma`) REFERENCES `tbforma` (`cod_Forma`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbprocesso_2` FOREIGN KEY (`cod_Materia`) REFERENCES `tbmateria` (`cod_TipoMateria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbprocesso_3` FOREIGN KEY (`cod_TipoProcesso`) REFERENCES `tbtipoprocesso` (`cod_TipoProcesso`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbprocesso`
--

LOCK TABLES `tbprocesso` WRITE;
/*!40000 ALTER TABLE `tbprocesso` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbprocesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbtipoprocesso`
--

DROP TABLE IF EXISTS `tbtipoprocesso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbtipoprocesso` (
  `cod_TipoProcesso` int(11) NOT NULL AUTO_INCREMENT,
  `de_TIpoProcesso` varchar(45) NOT NULL,
  `sg_TipoProcesso` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cod_TipoProcesso`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbtipoprocesso`
--

LOCK TABLES `tbtipoprocesso` WRITE;
/*!40000 ALTER TABLE `tbtipoprocesso` DISABLE KEYS */;
INSERT INTO `tbtipoprocesso` VALUES (1,'Judicial','J'),(2,'Procon','P');
/*!40000 ALTER TABLE `tbtipoprocesso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dbinolude'
--

--
-- Dumping routines for database 'dbinolude'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-22 21:08:34
